#!/usr/bin/env bash

java -jar CardToPDF.jar